package EjercicioTema3;

public class EjercicioTema3 {
    public static void main(String[] args) {

        String[] nombres = new String[]{"Adrian","Kevin","Lorena","Jesus","Mauri","Sergio"};

        for(int i = 0; i < nombres.length; i++) {
            System.out.println("Nombre numº "+i+" - "+nombres[i]);
        }

    }
}
