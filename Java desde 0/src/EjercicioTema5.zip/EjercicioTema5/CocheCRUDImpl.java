package EjercicioTema5;

public class CocheCRUDImpl implements CocheCRUD{

    public void save(){
        System.out.println("Metodo Guardar");
    }
    public void findAll(){
        System.out.println("Metodo buscar");
    }
    public void delete(){
        System.out.println("Metodo borrar");
    }
}
