package EjercicioTemas789;
import java.util.*;

public class Ejercicio1 {
    public static void main(String[] args) {
        String[] nombres = {"Adrian","Kevin","Emmanuel","Hector"};
        for (int i = 0; i < nombres.length; i++){
            System.out.println(nombres[i]+" ");
        }
    }
}
