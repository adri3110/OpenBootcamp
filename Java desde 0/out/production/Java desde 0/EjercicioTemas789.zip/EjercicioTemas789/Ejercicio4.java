package EjercicioTemas789;

public class Ejercicio4 {

    /*
    El problema de utilizar un vector para 1000 elementos seria que tardariamos mucho tiempo
     en introducirlos y posteriormente en recorrer ese vector hasta encontrar el dato
     requerido (por ejemplo mediante el bucle for).

     */
}
