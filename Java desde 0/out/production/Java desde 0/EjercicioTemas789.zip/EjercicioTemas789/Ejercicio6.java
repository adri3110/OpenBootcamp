package EjercicioTemas789;

import java.util.*;
import java.lang.*;

public class Ejercicio6 {
    public static void main(String[] args) {
        /* Crea un ArrayList de tipo int, y, utilizando un bucle rellénalo con elementos 1..10.
        A continuación, con otro bucle, recórrelo y elimina los numeros pares. Por último, vuelve
        a recorrerlo y muestra el ArrayList final. Si te atreves, puedes hacerlo en menos pasos,
        siempre y cuando cumplas el primer "for" de relleno.
         */
        ArrayList<Integer> nums = new ArrayList<Integer>();
        ArrayList<Integer> nums2 = new ArrayList<Integer>();

        // Añadiendo 10 numeros al ArrayList mediante bucle for
        for (int i=0; i <= 10; i++) {
            nums.add(i);
            //System.out.print(nums.get(i) + " ");
        }
        System.out.println(nums);

        //Imprimo el ArrayList y elimino los pares
        for(int i=0;i<nums.size();i++) {
            if (nums.get(i) instanceof Integer) {
                Integer aux = nums.get(i);
                if (aux % 2 != 0) {
                    nums2.add(i);
                    //System.out.print(nums2.add(i) + " ");
                }
            }
        }
        System.out.println(nums2);

    }
}


//codigo funcionando

    /*
    ArrayList<Integer> nums = new ArrayList<Integer>();

// Añadiendo 10 numeros al ArrayList mediante bucle for
        for (int i=0; i <= 10; i++) {
                nums.add(i);
                System.out.print(nums.get(i) + " ");
                }
                System.out.println("");
                //Imprimo el ArrayList y elimino los pares
                for(int i=0;i<nums.size();i++) {
        if (nums.get(i) instanceof Integer) {
        Integer aux = nums.get(i);
        if (aux % 2 == 0) {
        nums.remove(i);
        System.out.print(nums.get(i) + " ");
        }
        }
        }


     */