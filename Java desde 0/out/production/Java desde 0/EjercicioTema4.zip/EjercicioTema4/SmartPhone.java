package EjercicioTema4;

public class SmartPhone extends SmartDevice{

    public SmartPhone(){
    }
    public SmartPhone(String marca, String modelo, int memoria) {
        super(marca, modelo, memoria);
    }

}
