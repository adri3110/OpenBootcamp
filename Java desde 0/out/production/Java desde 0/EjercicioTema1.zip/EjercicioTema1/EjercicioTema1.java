package EjercicioTema1;

public class EjercicioTema1 {
    public static void main(String[] args) {

        //Declaracion de variables

        int num1 = 1;
        long num2 = 32424;
        double num3 = 1234.56;
        float num4 = 23.6f;
        boolean num5 = false;
        String nombre1 = "Nombre";
        char letra = 'A';

        //Imprimim,os dichas variables

        System.out.println("Numero entero: "+num1+" / Numero long: "+num2+" / Numero con decimales: "+num3+" /Numero Float: "+num4+" / Booleano: "+num5+"/ String: "+nombre1+" /Letra: "+letra);
    }

}
